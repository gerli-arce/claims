import type React from "react"

interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: "primary" | "outline" | "secondary" | "success" | "danger"
  size?: "sm" | "md" | "lg"
  children: React.ReactNode
}

export function Button({ variant = "primary", size = "md", className = "", children, ...props }: ButtonProps) {
  const getVariantClass = () => {
    switch (variant) {
      case "primary":
        return "tw-btn-primary"
      case "outline":
        return "tw-btn-outline"
      case "secondary":
       return "tw-btn-secondary"
      case "success":
         return "tw-btn-success"
      case "danger":
        return "tw-btn-danger"
      default:
        return "tw-btn-primary"
    }
  }

  const getSizeClass = () => {
    switch (size) {
      case "sm":
        return "tw-btn-sm"
      case "lg":
        return "tw-btn-lg"
      default:
        return ""
    }
  }

  return (
    <button className={`tw-btn ${getVariantClass()} ${getSizeClass()} ${className}`} {...props}>
      {children}
    </button>
  )
}
