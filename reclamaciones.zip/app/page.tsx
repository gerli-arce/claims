import App from "../resources/js/App"

export default function Page() {
  return <App />
}
